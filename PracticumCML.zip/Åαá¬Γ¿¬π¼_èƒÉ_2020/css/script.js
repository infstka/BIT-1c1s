<html lang="ru">
<head>
<meta charset="utf-8">
<title> java</title>
<style></style>
<script language="JavaScript" type="text/javascript">
  
var req;
  
function getFile(id) {
    str = "<embed src='" + id + "' width='700' height='500' />";
	document.getElementById('content').innerHTML = str;
};
   
  
</script>
</head>
<body>
</body>
</html>   